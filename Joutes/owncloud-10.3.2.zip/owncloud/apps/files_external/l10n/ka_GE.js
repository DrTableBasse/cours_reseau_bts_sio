OC.L10N.register(
    "files_external",
    {
    "External storage" : "ექსტერნალ საცავი",
    "Personal" : "პირადი",
    "Grant access" : "დაშვების მინიჭება",
    "Username" : "მომხმარებლის სახელი",
    "Password" : "პაროლი",
    "Save" : "შენახვა",
    "API key" : "API გასაღები",
    "WebDAV" : "WebDAV",
    "URL" : "URL",
    "Location" : "ადგილმდებარეობა",
    "ownCloud" : "ownCloud–ი",
    "Host" : "ჰოსტი",
    "Share" : "გაზიარება",
    "Name" : "სახელი",
    "External Storage" : "ექსტერნალ საცავი",
    "Folder name" : "ფოლდერის სახელი",
    "Configuration" : "კონფიგურაცია",
    "Add storage" : "საცავის დამატება",
    "Delete" : "წაშლა"
},
"nplurals=2; plural=(n!=1);");
