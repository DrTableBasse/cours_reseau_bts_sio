OC.L10N.register(
    "files_external",
    {
    "Personal" : "﻿ವೈಯಕ್ತಿಕ",
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Username" : "﻿ಬಳಕೆಯ ಹೆಸರು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Save" : "﻿ಉಳಿಸಿ",
    "WebDAV" : "﻿WebDAV",
    "URL" : "ಜಾಲದ ಕೊಂಡಿ",
    "Local" : "ಸ್ಥಳೀಯ",
    "Host" : "ಅತಿಥೆಯ-ಗಣಕ",
    "Share" : "﻿ಹಂಚಿಕೊಳ್ಳಿ",
    "Name" : "﻿ಹೆಸರು",
    "Delete" : "﻿ಅಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
