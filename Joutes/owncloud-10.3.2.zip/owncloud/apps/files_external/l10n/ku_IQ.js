OC.L10N.register(
    "files_external",
    {
    "Username" : "ناوی به‌کارهێنه‌ر",
    "Password" : "وشەی تێپەربو",
    "Save" : "پاشکه‌وتکردن",
    "URL" : "ناونیشانی به‌سته‌ر",
    "Location" : "شوێن",
    "Share" : "هاوبەشی کردن",
    "Name" : "ناو",
    "Folder name" : "ناوی بوخچه"
},
"nplurals=2; plural=(n != 1);");
