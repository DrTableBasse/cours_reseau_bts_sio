OC.L10N.register(
    "files_external",
    {
    "Username" : "ਯੂਜ਼ਰ-ਨਾਂ",
    "Password" : "ਪਾਸਵਰ",
    "ownCloud" : "ਓਵਨਕਲਾਉਡ",
    "Share" : "ਸਾਂਝਾ ਕਰੋ",
    "Folder name" : "ਫੋਲਡਰ ਨਾਂ",
    "Delete" : "ਹਟਾਓ"
},
"nplurals=2; plural=(n != 1);");
