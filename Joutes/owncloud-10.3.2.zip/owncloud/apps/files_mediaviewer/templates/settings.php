<?php
style('user_ldap', 'files_mediaviewer');
script('user_ldap', 'files_mediaviewer');
?>

<section id="files_mediaviewer">
    <div>
        <!-- Mountpoint -->
    </div>
</section>