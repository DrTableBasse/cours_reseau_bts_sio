OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "Ekhavu la aplikaĵojn por sinkronigi viajn dosierojn",
    "Desktop client" : "Labortabla kliento",
    "Android app" : "Android-aplikaĵo",
    "iOS app" : "iOS-aplikaĵo",
    "Connect your desktop apps to %s" : "Konekti viajn labortablajn aplikaĵojn al %s",
    "Connect your Calendar" : "Konektu vian Kalendaron",
    "Connect your Contacts" : "Konektu viajn Kontaktojn",
    "Documentation" : "Dokumentaro",
    "Access files via WebDAV" : "Atingu dosierojn per WebDAV",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Estas pli da informo en la <a target=\"_blank\" href=\"%s\">dokumentaro</a> kaj en nia <a target=\"_blank\" href=\"http://owncloud.org\">TTT-ejo</a>."
},
"nplurals=2; plural=(n != 1);");
