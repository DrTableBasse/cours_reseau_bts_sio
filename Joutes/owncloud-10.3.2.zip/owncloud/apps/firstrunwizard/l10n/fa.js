OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "برنامه ها را دریافت کنید تا فایل هایتان را همگام سازید",
    "Desktop client" : "نرم افزار دسکتاپ",
    "Android app" : "اپ اندروید",
    "iOS app" : "اپ iOS",
    "Connect your desktop apps to %s" : "اتصال برنامه دسکتاب خود به %s",
    "Connect your Calendar" : "اتصال تقویم خودتان",
    "Connect your Contacts" : "اتصال مخاطبان شما",
    "Documentation" : "مستندسازی",
    "Access files via WebDAV" : "دسترسی فایل ها از طریق WebDAV",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "اطلاعات بیشتر در بخش <a target=\"_blank\" href=\"%s\"> مستندات </a> و در <a target=\"_blank\" href=\"http://owncloud.org\"> وبسایت </a> قرار دارد."
},
"nplurals=2; plural=(n > 1);");
