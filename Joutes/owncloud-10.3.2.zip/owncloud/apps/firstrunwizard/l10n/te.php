<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "మీ వ్యక్తిగత జాల సేవలు. మీ దస్త్రాలు, పరిచయాలు, క్యాలెండర్ ఇంకా మరెన్నో, అన్నీ ఒకే చోట."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
